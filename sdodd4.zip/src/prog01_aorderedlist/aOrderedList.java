package prog01_aorderedlist;
import java.util.Arrays;
/**
* aOrderedList.java is meant to create and deal with a ordered array of comparable objects
* The class handles the creation of the array, adding objects to the array, removing objects from the array, and many other actions related to accessing the array.
* 
*
* CSC 1351 Programming Project No 1
*
* Section 2
*
* @author Steven Dodd
* @since 3/17/2024
*
*/
public class aOrderedList {
    final int SIZEINCREMENTS = 20; //denotes amount to increment the arraylist by
    private Comparable[] oList; //creates oList to store the ordered list
    private int listSize; // stores list size
    private int numObjects; //stores the amount of objects currently stored
    private int curr; //stores the current iteration of the array

    public aOrderedList() {
        numObjects = 0; //sets numObjects to 0
        listSize = SIZEINCREMENTS; //sets listSize to the increment size
        oList = new Car[listSize]; //creates the array with specified list size
    }
    
/**
* The add method adds a comparable which is taken in to the created ordered list. It first finds where in the list this object should be added based on the 
* compareTo method in the Car class and then shifts things that should be after it in the list to the right before inserting it into the ordered list.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public void add(Comparable newObject) {
        if (numObjects == listSize) { //if the array is at maximum capacity 
            listSize += SIZEINCREMENTS; //increment the array size
            oList = Arrays.copyOf(oList, listSize); // create new array with new size and copied data
        }
        if (numObjects==0){ //if this is the first object being added
            oList[0]=newObject; // sets 0th position to newObject
            numObjects++; //increment numObjects
        }
        else{
            int i; //creates integer i to be used for the loop and insertion of the newObject
            for (i = 0; i < numObjects; i++) {
                if (newObject.compareTo(oList[i]) > 0) { //if the newObject should be before the object at i, exit the loop
                    break;
                } 
            }     
            reorderList(i); //calls reorderlist at index i
            oList[i] = newObject; //adds newObject at the ith position
            numObjects++; //increment numobjects
        }
    }

    public void reorderList(int index){
        for(int i=numObjects;i>=index;i--){ //from the end of the array to the index value scoot all values to the right
            if (i!=0) oList[i]=oList[i-1]; 
        }
    }

/**
* The size method recalculates the number of objects in the array. This could be removed and simply return numObjects, and it would be more efficient if I did do that,
* however I kept it this way as a safety precaution so that numObjects could be recalculated if needed. The size method is seldom called so this is not a major time loss
* currently, but it would be beneficial to change this when dealing with more data. This is an incredibly easy fix, i could simply only use return numObjects.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public int size() {
        numObjects=0; //reset numObjects
        for (Comparable oList1 : oList) { //run through the array and increment numObjects if the object exists
            if (oList1!=null) numObjects++;
        }
        return numObjects; // return numObjects
    }

/**
* The getMake method returns the value of make for a given car object
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public Comparable get(int index) {
        return oList[index]; //returns the object at the specified index
    }

/**
* The isEmpty method returns true if there are no objects stored in the array.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public boolean isEmpty() {
        return size() == 0; //returns true if the array is empty, false otherwise
    }
    
/**
* The reset method resets the incrementing variable to 0.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public void reset(){
        curr=0; //resets the increment variable
    }
    
/**
* The next method returns the next car in oList and increments the incrementing variable curr.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public Comparable next(){
        return oList[curr++]; //increment curr and return the next object in the array
    }
    
/**
* The hasNext method returns true if there is another car when the curr variable gets incremented.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public boolean hasNext(){
        return curr<numObjects; //returns true if there are more objects in the array
    }
    
/**
* The remove() method uses the increment variable curr and calls the remove(int) method to remove the current element from the array.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public void remove(){
        remove(curr); //calls remove to remove the current object
    }

/**
* The remove(int) method takes in an integer and removes the car object at that index in the array. It then shifts other elements down and decrements the numObjects variable.
* This is my prior implementation of remove and I decided to keep using it with the new implementation. Though it is unoptimal, it gives an additional interaction which could prove userful.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
public void remove(int index) {
    for (int i = index; i < numObjects; i++) { //scoots everything to the right of the removed value to the left
        oList[i] = oList[i + 1]; 
    }
    oList[numObjects - 1] = null; //replaces the last value in the list with null as it has been copied to the left
    numObjects--; //decrement numobjects
    }

/**
* The remove(string, int) method takes in the make and year of a car object and searches through the array for the first incident of that combination of make and year.
* After finding the first instance it calls the remove(int) method to remove the car from the array and shift other members of the array down one.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public void remove(String make, int year) {
        for (int i = 0; i < numObjects; i++) { //for each car check if the make and year match the inputted make and year, if so call remove(int) method to remove them
            if (oList[i] instanceof Car) {
                Car car = (Car) oList[i];
                if (car.getMake().equals(make) && car.getYear() == year) {
                    remove(i);
                    return; //exit loop after finding first iteration that matches
                }
            }
        }
    }

    /**
* The toString method overrides the object toString method and uses the toString method of the Car class in its usage to output the string in the proper format to the 
* document at the end of the program.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    @Override
    public String toString() {
        String output="";
        for (Comparable oList1 : oList){
            if (oList1!=null){
                output=output+"["+oList1.toString()+"]\n"; //constructs output variable for the data to be stored in the outputfile
            }
            
        }
        return output; //returns output variable
    }
}
