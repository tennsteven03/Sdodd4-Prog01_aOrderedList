package prog01_aorderedlist;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
* The class is the entry point to the program. It reads data from a file, which is specified by the user and contains instructions to add or remove car objects from the ordered list.
* It manipulates the list of cars based on the data read from the file. It then writes the contents of the list to an output file in a specified format.
*
* CSC 1351 Programming Project No 1
*
* Section 2
*
* @author Steven Dodd
* @since 3/17/2024
*
*/
public class Prog01_aOrderedList {
    public static void main(String[] args) {
        Scanner scanner=getFileName("Enter input filename: "); //created scanner scanner and calls getFileName to get the name for the input data
        aOrderedList orderedList=new aOrderedList(); //creates aOrderedList orderedList to store the car objects
        while (scanner.hasNextLine()) { //while there is more in the text document
            String line = scanner.nextLine(); //line=next line in document
            String[] parts = line.split(","); //splits line into parts delimited by ","
        if (parts[0].equals("A")) {
            String make = parts[1]; //make = the 2nd segment
            int year = 0; 
            int price = 0; 
            try {
                year = Integer.parseInt(parts[2]); //attempts to set year to the 3rd segment
                price = Integer.parseInt(parts[3]); //attempts to set price to the 4th segment
            } catch (NumberFormatException e) { //if either of the previous parses cause an error output the line and tell the user it was not valid
                System.out.println("Invalid year or price format: " + line);
                continue;
            }
            Car newCar = new Car(make, year, price);
            orderedList.add(newCar); //adds newCar to the orderedList
            }else if (parts[0].equals("D")) { // if the line says to delete
                String make = parts[1]; //make = the 2nd segment
                int year = 0; // set year to 0
                try {
                    year = Integer.parseInt(parts[2]); //attempt to set year to segment 3
                } catch (NumberFormatException e) { //if year cannot be set to segment 3 output that the line is invalid to the user
                    System.out.println("Invalid year format: " + line);
                    continue;
                } // year = segment 3
                orderedList.reset(); //reset curr to 0
                while (orderedList.hasNext()) { //while there are more cars in the orderedList
                     Car car = (Car) orderedList.next(); // Take in a new car
                    if (car!=null){
                        if (car.getMake().equals(make) && car.getYear() == year) { //check if the car matches the delete request
                        orderedList.remove(); // if it matches remove the car from the list
                        break; // exit loop after finding a match
                        }
                    }
                }
            }
        }
        
        scanner.close(); // closes scanner as it is no longer needed
        
        PrintWriter writer = getOutputFile("Enter output filename: "); // calls getOutputFile to get the name for the new file containing the data
        writer.println(orderedList.toString()); // calls the toString method to list all the objects in the format for output
        writer.close(); // closes writer as its no longer needed
    }
    
/**
* The getFileName method gets the name of the file meant to be used as input from the user.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    static Scanner getFileName(String outputPrompt){
        Scanner scanner=new Scanner(System.in); //creates scanner 
        boolean fileExists=false; //boolean for in case file does not exist
        File file; // creates File file
        
        while(!fileExists) { //while fileexists=false
            System.out.print(outputPrompt); //print outputprompt to user
            String fileName= scanner.nextLine(); // filename = userinput
            if(fileName.length()>3){ //if the file is longer than 3 characters
                if(fileName.substring(fileName.length()-4).compareTo(".txt")!=0) fileName=fileName+".txt";// if filename does not end in .txt, append .txt
            } else fileName=fileName+".txt"; // append .txt if the program is under 4 characters as it cannot contain .txt in this case
            file=new File(fileName); //get data from filename
            if(file.exists()) { 
                try {
                    scanner = new Scanner(file); //creates a scanner for the file
                    fileExists = true; // ends loop condition
                }
                catch(FileNotFoundException exception){ // if the file does not exist
                    throw new RuntimeException("Unable to find and open file for reading."); //output to user file doesnt exist
                }
            } else{
                System.out.println("File specified <" + fileName + "> does not exist."); //output file does not exist
                System.out.print("Would you like to continue? <Y/N> "); // outputs asking if the user would like to continue
                String choice = scanner.nextLine(); // gets choice from user
                if (choice.trim().substring(0,1).equalsIgnoreCase("N")) { // if their choice begins with an n the program will terminate, otherwise it will continue
                    System.exit(0);
                }
            }
        }
        return scanner; 
    }
/**
* The getOutputFile method gets a name from the user to give to the file outputted at the end of the program which will contain all the data manipulated by the program.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    static PrintWriter getOutputFile(String outputPrompt) {
        Scanner scanner = new Scanner(System.in); //creates scanner
        boolean fileExists = false; //boolean for in case file can not create
        PrintWriter writer = null; //creates writer

        while (!fileExists) {//while fileexists=false
            System.out.print(outputPrompt); //output prompt to user
            String fileName = scanner.nextLine(); // get filename from user
            if (fileName.length()>3){//if longer than 4 characters
                if (fileName.substring(fileName.length()-4).compareTo(".txt")!=0) fileName=fileName+".txt"; // if does not end in .txt, append .txt
            } else fileName=fileName+".txt"; // append .txt if the program is under 4 characters as it cannot contain .txt in this case
            File file = new File(fileName); //new file with filename from user
            try {
                writer = new PrintWriter(file); //try to create file
                fileExists = true; //file now exists
            } catch (FileNotFoundException exception) { // if file cannot create
                System.out.println("Unable to create file: " + fileName); //output there was an issue
                System.out.print("Would you like to continue? <Y/N> "); //prompt user to continue
                String choice = scanner.nextLine(); //get user input
                if (choice.trim().substring(0,1).equalsIgnoreCase("N")) { // if their choice begins with an n the program will terminate, otherwise it will continue
                    System.exit(0);
                }
            }
        }
        return writer;
    }


}