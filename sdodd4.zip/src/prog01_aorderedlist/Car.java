package prog01_aorderedlist;
/**
* The car class represents car objects with attributes such as make, year and price. It provides methods to access these attributes and compare different car objects.
*
* CSC 1351 Programming Project No 1
*
* Section 2
*
* @author Steven Dodd
* @since 3/17/2024
*
*/
public class Car implements Comparable<Car>{
    private final String make; //stores the make of the car object
    private final int year;  //stores the year of the car object
    private final int price; //stores the price of the car object
    
    /**
    * The Car(string, int, int) constructor is our only constructor for the program and takes in the three parameters used as input variables for the car object.
    *
    * CSC 1351 Programming Project No 1
    * Section 2
    *
    * @author Steven Dodd
    * @since 3/17/24
    *
    */
    public Car(String Make, int Year, int Price){  // sets the values of make, year, and price
        this.make=Make;
        this.year=Year;
        this.price=Price;
    }

/**
* The getMake method returns the value of make for a given car object
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public String getMake(){  
        return make;
    }
    
/**
* The getYear method returns the value of year for a given car object
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public int getYear(){
        return year;
    }
    
/**
* The getPrice method returns the value of Price for a given car object
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    public int getPrice(){ 
        return price;
    }
    
/**
* The compareTo method overrides the compareTo method for the comparable class with our own usage to be able to sort the car objects by order of make and year.
* This involves returning a negative value, positive value, or zero depending on how the objects compare either alphabetically or numerically.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
     * @param other
* @since 3/17/24
*
*/
    @Override
    public int compareTo(Car other){  //  car1 < car2 under the following conditions: 1. car1.make < car2.make   2. car1.make == car2.make && car1.year < car2.year
        if (other!=null){ // if other car exists
            if (other.getMake().compareTo(this.make)==0) return other.getYear()-this.year;  // If car1 make = car2 make return the difference of years
                else return other.getMake().compareTo(this.make);  // If car1 make != car2 make return the difference in make
        }
        return 0; // if the other does not exist the file can be entered in the 0th position as it is the first object added
    }

/**
* The toString method overrides the object toString method and returns a string containing all the data for a given car object.
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Steven Dodd
* @since 3/17/24
*
*/
    @Override
    public String toString(){  

        return "Make: " + make + ", Year : " + year + ", Price: " + price + ";"; //  returns the following string: “Make: “ + make + “, Year : “ + year + “, Price: “ + price + “;”
    }

}
